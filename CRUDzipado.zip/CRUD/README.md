Eletrônica Domingos: esse sistema é um sistema gerenciador de ordens de serviço, construindo-se em html, css, javascript, node.js, express generator, ejs e bootstrap, o bando de dados sendo o MySQL. Esse sistema sistema tem as seguintes funções necessárias:
1. Cadastrar nova ordem de serviço;
2. Visualizar e editar ordens de serviço pendentes;
3. visualizar ordens de serviço concluídas;
4. visualizar clientes e seus aparelhos/consertos/ordens de serviço cadastradas no sistema;
5. o cliente é cadastrado dentro do cadastro da ordem de serviço, ou seja, não tem uma página separada pra isso, está dentro da pagina de cadastro de novo conserto. O mesmo vale para endereço. O endereço só é cadastrado quando o cliente escolher receber no endereço, e também na página de novo conserto.
6. o banco de dados se organiza da seguinte forma:
            CREATE DATABASE CRUD;

            USE CRUD;

            CREATE TABLE Endereco (
            id integer primary key auto_increment not null,
            rua varchar(40) not null,
            numero integer,
            bairro varchar(40) not null,
            complemento varchar(20) not null,
            cidade varchar(40) not null,
            UF char(2) not null,
            CEP char(9) not null
            );

            CREATE TABLE Cliente (
            id integer primary key auto_increment not null,
            nome varchar(50) not null,
            fone varchar (15) not null,
            rg integer not null unique,
            cpf integer not null unique,
            obs varchar (100),
            id_endereco integer not null,
            foreign key (id_endereco) references Endereco (id)
            );

            CREATE TABLE Aparelho (
            id integer primary key auto_increment not null,
            nome varchar (50) not null,
            marca varchar (25) not null,
            cor varchar (20) not null,
            modelo varchar (40) not null,
            problema varchar (70) not null,
            garantia boolean,
            data_garantia date,
            fotos blob,
            tipo varchar (30) not null,
            acessorios varchar (50),
            obs varchar (100),
            id_cliente integer not null,
            foreign key (id_cliente) references Cliente (id)
            );

            CREATE TABLE Funcionario (
            id integer primary key auto_increment not null,
            nome varchar(50) not null,
            email varchar (50) not null unique,
            senha varchar (25) not null,
            usuario varchar (40) not null
            );

            CREATE TABLE Registro (
            id integer primary key auto_increment not null,
            data_registro date not null,
            data_estimada date not null,
            data_entrega date not null,
            orcamento real not null,
            valor real not null,
            status_aparelho integer,
            obs varchar(100),
            id_funcionario integer not null,
            id_aparelho integer not null,
            foreign key (id_funcionario) references Funcionario (id),
            foreign key (id_aparelho) references Aparelho (id)
            );

preciso que me ajude a construir a parte de routes, controllers e models, para que este sistema funcione corretamente. as telas front-end eu já as possuo, não precisa faze-las. só preciso de ajuda com o back-end, por favor.