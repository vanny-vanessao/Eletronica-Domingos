const express = require('express');
const router = express.Router();
const registroController = require('../controllers/registroController');

// Página de listagem dos pendentes
router.get('/', (req, res) => {
  // Aqui você pode chamar um controller para listar os registros pendentes
  res.render('pendentes/index'); // ajuste o caminho da view se necessário
});

// Página do formulário de novo conserto
router.get('/novo-cliente', (req, res) => {
  res.render('pendentes/novo-conserto1'); // ajuste o caminho da view se necessário
});

// rota que recebe o POST do formulário
router.post('/novo-conserto1', registroController.criarOrdem);

// Exibe o formulário da segunda etapa
router.get('/novo-aparelho', (req, res) => {
  res.render('pendentes/novo-conserto2');
});

// Processa o POST da segunda etapa (se necessário)
router.post('/novo-conserto2', registroController.criarOrdem);

module.exports = router;