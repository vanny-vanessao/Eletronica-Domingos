const bcrypt = require('bcrypt');
const db = require('../config/db');

exports.renderCadastro = (req, res) => {
  res.render('cadastro', { erro: null, sucesso: null });
};

exports.cadastrarFuncionario = (req, res) => {
  
  const { nome, email, usuario, senha } = req.body;

  if (!nome || !email || !usuario || !senha) {
    return res.render('cadastro', { erro: 'Preencha todos os campos.', sucesso: null });
  }

  db.query('SELECT * FROM Funcionario WHERE email = ? OR usuario = ?', [email, usuario], (err, results) => {
    if (err) return res.render('cadastro', { erro: 'Erro no servidor.', sucesso: null });

    if (results.length > 0) {
      return res.render('cadastro', {
        erro: 'Já existe um funcionário com este email ou usuário.',
        sucesso: null
      });
    }

    bcrypt.hash(senha, 10, (err, hash) => {
      if (err) return res.render('cadastro', { erro: 'Erro ao criptografar a senha.', sucesso: null });

      db.query(
        'INSERT INTO Funcionario (nome, email, senha, usuario) VALUES (?, ?, ?, ?)',
        [nome, email, hash, usuario],
        (err, result) => {
          if (err) return res.render('cadastro', { erro: 'Erro ao cadastrar funcionário.', sucesso: null });

          res.render('cadastro', {
            erro: null,
            sucesso: 'Funcionário cadastrado com sucesso!'
          });
        }
      );
    });
  });
};
